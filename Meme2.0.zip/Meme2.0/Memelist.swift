//
//  Meme.swift
//  pickImage
//
//  Created by Ma Ding on 16/11/27.
//  Copyright © 2016年 Ma Ding. All rights reserved.
//

import Foundation
import UIKit

struct Memelist {
    var topText: String?
    var bottomText: String?
    var originalImage: UIImage?
    var memedImage: UIImage
}
    
