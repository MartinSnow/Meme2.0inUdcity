//
//  memeTableViewController.swift
//  pickImage
//
//  Created by Ma Ding on 16/11/27.
//  Copyright © 2016年 Ma Ding. All rights reserved.
//

import UIKit

class memeTableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var memeList: [Memelist]! = []
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return memeList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "memeTableView", for: indexPath)
        let match = self.memeList[(indexPath as IndexPath).row]
        cell.imageView!.image = match.memedImage
        cell.textLabel!.text = match.topText
        cell.detailTextLabel!.text = match.bottomText
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailController = self.storyboard?.instantiateViewController(withIdentifier: "memeDetailViewController") as! memeDetailViewController
        detailController.memeList = self.memeList[(indexPath as IndexPath).row]
        self.navigationController!.pushViewController(detailController, animated: true)
    }
    


}
