//
//  ViewController.swift
//  pickImage
//
//  Created by Ma Ding on 16/11/10.
//  Copyright © 2016年 Ma Ding. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {

    @IBOutlet weak var imagePickerView: UIImageView!
    @IBOutlet weak var camera: UIBarButtonItem!
    @IBOutlet weak var top: UITextField!
    @IBOutlet weak var bottom: UITextField!
    @IBOutlet weak var shareButton: UIBarButtonItem!
    @IBOutlet weak var bottomToolbar: UIToolbar!
    
    var memeList = [Memelist]()
    
    var shareIsEnable = false

    let textAttributes:[String: Any] = [NSStrokeColorAttributeName: UIColor.black,
        NSForegroundColorAttributeName: UIColor.white,
        NSFontAttributeName: UIFont(name: "HelveticaNeue-CondensedBlack", size: 35)!,
        NSStrokeWidthAttributeName: -3.0]

    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        camera.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        shareButton.isEnabled = shareIsEnable
        subscribeToKeyboardNotifications()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
    }
    
    override func viewDidLoad() {
        
        top.delegate = self
        bottom.delegate = self
        
        super.viewDidLoad()
        configure(textField: top, text: "TOP")
        configure(textField: bottom, text: "BOTTOM")
    }
    
    override var prefersStatusBarHidden: Bool{
        return true
    }

    @IBAction func pickAnImageFromAlbum(_ sender: AnyObject) {
        imagePickerWith(sourceType: .photoLibrary)
    }
    @IBAction func pickAnImageFromCamera(_ sender: AnyObject) {
        imagePickerWith(sourceType: .camera)
    }
    @IBAction func share(_ sender: AnyObject) {
        let memedImage = generateMemedImage()
        let controller = UIActivityViewController(activityItems: [memedImage], applicationActivities: nil)
        controller.completionWithItemsHandler = {
            (activityType, completed, returnedItems, activityError) in
            if completed {
                self.save()
            }
        }
        self.present(controller, animated: true, completion: nil)
    }
    @IBAction func cancel(_ sender: AnyObject) {
        self.dismiss(animated: true, completion: nil)
    }
    func showList() {
        let storyboard = self.storyboard
        let controller = storyboard?.instantiateViewController(withIdentifier: "memeTableViewController") as! memeTableViewController
        controller.memeList = self.memeList
        self.present(controller, animated: true, completion: nil)
    }
    
    
    
    func configure(textField: UITextField, text: String){
        textField.text = text
        textField.defaultTextAttributes = textAttributes
        textField.textAlignment = .center
    }
    
    func imagePickerWith(sourceType: UIImagePickerControllerSourceType){
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = sourceType
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
            imagePickerView.image = image
            shareIsEnable = true
        }
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField.text == "TOP" || textField.text == "BOTTOM" {
            textField.text = ""
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func subscribeToKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: .UIKeyboardWillHide, object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    func keyboardWillShow(notification:Notification) {
        if bottom.isFirstResponder {
            view.frame.origin.y = 0 - getKeyboardHeight(notification: notification)
        }
    }
    
    func keyboardWillHide(notification:Notification) {
        view.frame.origin.y = 0
    }
    
    func getKeyboardHeight(notification:Notification) -> CGFloat {
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue
        return keyboardSize.cgRectValue.height
    }
    
    func save() {
        let meme = Memelist(topText: top.text!, bottomText: bottom.text!, originalImage: imagePickerView.image!, memedImage: generateMemedImage())
            memeList.append(meme)
        self.showList()
    }
    
    func generateMemedImage() -> UIImage {
        toolbarItems?.removeAll()
        navigationItem.hidesBackButton = true

        bottomToolbar.isHidden = true
        // Render view to an image
        UIGraphicsBeginImageContext(view.frame.size)
        view.drawHierarchy(in: view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        bottomToolbar.isHidden = false
        return memedImage
    }


}

