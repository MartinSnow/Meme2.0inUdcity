//
//  memeDetailViewController.swift
//  pickImage
//
//  Created by Ma Ding on 16/12/2.
//  Copyright © 2016年 Ma Ding. All rights reserved.
//

import UIKit

class memeDetailViewController: UIViewController {
    
    var memeList: Memelist!

    @IBOutlet weak var memeDetailImage: UIImageView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
        self.memeDetailImage!.image = self.memeList.memedImage
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
    }
    @IBAction func cancel(_ sender: AnyObject) {
        dismiss(animated: true, completion: nil)
    }


}
