//
//  memeCollectionViewCell.swift
//  pickImage
//
//  Created by Ma Ding on 16/12/12.
//  Copyright © 2016年 Ma Ding. All rights reserved.
//

import UIKit

class memeCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var cellImage: UIImageView!
    @IBOutlet weak var cellTopLabel: UILabel!
    @IBOutlet weak var cellBottomLabel: UILabel!


}
