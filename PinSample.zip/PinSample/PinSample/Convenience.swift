//
//  Convenience.swift
//  PinSample
//
//  Created by Ma Ding on 17/4/13.
//  Copyright © 2017年 Udacity. All rights reserved.
//

import Foundation
import UIKit

extension UdacityClient {
    
    func authenticateWithViewController(_ hostViewController: UIViewController, completionHandlerForAuth: @escaping (_ success: Bool, _ errorString: String?) -> Void) {
        
        getUserId() {(success, userId, errorString) in
            if success {
                if let userId = userId {
                    self.getUserData(userId: userId) { (success, userData, errorString) in
                        if success {
                            //print ("userData is \(userData)")
                        }
                        completionHandlerForAuth(success, errorString)
                    }
                } else {
                    completionHandlerForAuth(success, errorString)
                }
            } else {
                completionHandlerForAuth(success, errorString)
            }
        }
    
    }
    
    private func getUserId(_ completionHandlerForUserID: @escaping (_ success: Bool, _ userID: String?, _ errorString: String?) -> Void) {
        
        let _ = postSessionWithUdAPI() { (result, error) in
            
            if let error = error {
                print(error)
                completionHandlerForUserID(false, nil, "Login Failed (User ID).")
            } else {
                if let account = result?["account"] as? [String:AnyObject] {
                    if let userId = account["key"] as? String {
                        completionHandlerForUserID(true, userId, nil)
                    } else {
                        print ("Could not find userId.")
                        completionHandlerForUserID(false, nil, "Login Failed (User ID).")
                    }
                } else {
                    print("Could not find account.")
                    completionHandlerForUserID(false, nil, "Login Failed (User ID).")
                }
            }
        }
    }
    
    private func getUserData(userId: String?, _ completionHandlerForUserData: @escaping (_ success: Bool, _ userData: [String:AnyObject]?, _ errorString: String?) -> Void) {
        
        let userId = userId!
        let _ = getPublicUserData(userId: userId) { (result, error) in
            if let error = error {
                print (error)
                completionHandlerForUserData(false, nil, "Fail to get userData")
            } else {
                let userResult = result!
                //print ("")
                //print ("result is \(userResult)")
                if let userData = userResult["user"] as? [String:AnyObject] {
                    //print ("userData is \(userData)")
                    completionHandlerForUserData(true, userData, nil)
                } else {
                    print ("Could not find userData")
                }
            }
        }
    }

}
