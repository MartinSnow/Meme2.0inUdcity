//
//  DetailViewController.swift
//  PinSample
//
//  Created by Ma Ding on 17/4/18.
//  Copyright © 2017年 Udacity. All rights reserved.
//

import Foundation
import UIKit

class detailViewController: UIViewController {
    
    var studentInformation = [String: AnyObject]()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let app = UIApplication.shared
        if let toOpen = studentInformation["mediaURL"] as? String {
            app.openURL(URL(string: toOpen)!)
        }
    }
}
