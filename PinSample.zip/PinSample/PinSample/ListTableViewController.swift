//
//  ListTableViewController.swift
//  PinSample
//
//  Created by Ma Ding on 17/4/12.
//  Copyright © 2017年 Udacity. All rights reserved.
//

import UIKit

class ListTableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIApplicationDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    var studentInformation = [[String: AnyObject]]()
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidAppear(_ animated: Bool) {
        tableView?.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        studentInformation = StudentInformation.student.studentInformation
        return studentInformation.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "StudentCell", for: indexPath)
        let match = self.studentInformation[(indexPath as IndexPath).row]
        let firstName = match["firstName"] as! String
        let lastName = match["lastName"] as! String
        cell.textLabel!.text = "\(firstName) \(lastName)"
        cell.detailTextLabel!.text = match["mediaURL"] as! String
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailController = self.storyboard?.instantiateViewController(withIdentifier: "detailViewController") as! detailViewController
        detailController.studentInformation = self.studentInformation[(indexPath as IndexPath).row]
        self.navigationController!.pushViewController(detailController, animated: true)
    }
    

}
